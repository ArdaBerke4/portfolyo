import pandas as pd

try:
    # 1. Listeyi oku
    df = pd.read_csv('buyuk_depremler_v3.csv', encoding='utf-8-sig', sep=';')

    # 2. Gelişmiş Fay Hattı Eşleştirme Fonksiyonu
    def fay_bul(yer):
        yer = str(yer).upper()
        
        # Kuzey Anadolu Fay Hattı (KAF) ve Kolları
        kaf_iller = ['TOKAT', 'ERZİNCAN', 'BOLU', 'DÜZCE', 'SAKARYA', 'KOCAELİ', 'TEKİRDAĞ', 
                     'YALOVA', 'İSTANBUL', 'AMASYA', 'ÇANKIRI', 'KASTAMONU', 'ERZURUM', 'YALOVA']
        
        # Doğu Anadolu Fay Hattı (DAF) ve Ölü Deniz Fayı Etkisi
        daf_iller = ['KAHRAMANMARAŞ', 'HATAY', 'ADIYAMAN', 'ELAZIĞ', 'MALATYA', 'BİNGÖL', 
                     'OSMANİYE', 'GAZİANTEP', 'KİLİS', 'MUŞ']
        
        # Batı Anadolu Fay Sistemi (BAFS) - Graben Sistemleri
        bafs_iller = ['İZMİR', 'AYDIN', 'DENİZLİ', 'MANİSA', 'MUĞLA', 'KÜTAHYA', 'AFYON', 
                      'UŞAK', 'BALIKESİR', 'ÇANAKKALE', 'BURDUR', 'ISPARTA', 'EGE DENİZİ']

        # Eşleştirme Mantığı
        if any(x in yer for x in kaf_iller):
            return 'Kuzey Anadolu Fay Hattı (KAF)'
        elif any(x in yer for x in daf_iller):
            return 'Doğu Anadolu Fay Hattı (DAF)'
        elif any(x in yer for x in bafs_iller):
            return 'Batı Anadolu Fay Sistemi (BAFS)'
        elif 'VAN' in yer:
            return 'Van Fay Zonu / Doğu Anadolu Fay Sistemi'
        elif 'ADANA' in yer:
            return 'Kozan-Savrun Fay Zonu (DAF Kolu)'
        elif 'ANTALYA' in yer or 'AKDENİZ' in yer:
            return 'Helenik-Kıbrıs Yayı Dalma-Batma Zonu'
        elif any(x in yer for x in ['KONYA', 'ANKARA', 'NİĞDE', 'AKSARAY', 'KIRŞEHİR']):
            return 'İç Anadolu Fay Sistemleri'
        elif 'HAKKARİ' in yer or 'ŞIRNAK' in yer:
            return 'Bitlis-Zagros Kenet Kuşağı'
        else:
            return 'Yerel Fay Hattı / Bölgesel Sismik Kaynak'

    # 3. Yeni sütunu oluştur
    df['Fay_Hatti_Adi'] = df['Location'].apply(fay_bul)

    # 4. Kaydet
    df.to_csv('buyuk_depremler_final_liste.csv', index=False, encoding='utf-8-sig', sep=';')
    print("İşlem tamam! Tüm şehirler ve bölgeler ana fay sistemlerine göre eşleştirildi.")

except Exception as e:
    print(f"Hata: {e}")