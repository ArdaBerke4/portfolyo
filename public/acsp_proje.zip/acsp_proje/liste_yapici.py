import pandas as pd

# Orijinal dosyayı okurken AFAD genelde UTF-8 kullanır.
# Eğer yine hata verirse encoding='iso-8859-9' yaparsın.
try:
    df = pd.read_csv('data.csv', encoding='utf-8', sep=None, engine='python')
    
    # Lokasyon isimlerindeki boşlukları ve karakterleri korumak için
    # Magnitude filtrelemesini yapalım
    df['Magnitude'] = pd.to_numeric(df['Magnitude'], errors='coerce')
    buyuk_depremler = df[df['Magnitude'] >= 5.0].copy()

    # Excel'in bozmaması için "utf-8-sig" ile kaydediyoruz
    buyuk_depremler.to_csv('buyuk_depremler_v3.csv', index=False, encoding='utf-8-sig', sep=';')
    
    print("Yeni veri başarıyla işlendi! Artık 'Tuşba' yazması lazım.")
except Exception as e:
    print(f"Hata: {e}")