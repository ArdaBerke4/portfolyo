import pandas as pd
import folium
from folium.plugins import HeatMap

try:
    # 1. Veriyi Oku: Ayırıcıyı (sep) otomatik deniyoruz, bozuk satırları atlıyoruz (on_bad_lines)
    # AFAD/Kandilli verileri bazen ';' bazen ',' kullanır.
    df = pd.read_csv('data.csv', encoding='latin-1', sep=None, engine='python', on_bad_lines='skip')
    
    print("Veri başarıyla okundu. Sütunlar:", df.columns.tolist())

    # 2. Koordinat Sütunlarını Temizle (Task 1c Raporun için kritik!)
    # Boş verileri (NaN) uçuruyoruz
    df = df.dropna(subset=['Latitude', 'Longitude'])

    # 3. Harita Hazırlığı
    m = folium.Map(location=[39.0, 35.0], zoom_start=6)

    # 4. Veriyi Isı Haritasına Uygun Formata Getir
    # Koordinatları float (ondalık sayı) yaptığımızdan emin oluyoruz
    heat_data = [[float(row['Latitude']), float(row['Longitude'])] for index, row in df.iterrows()]

    # 5. Ekle ve Kaydet
    HeatMap(heat_data).add_to(m)
    m.save('turkiye_sismik_yogunluk_haritasi.html')
    
    print(f"\nİşlem Tamam! {len(heat_data)} adet deprem verisi haritaya işlendi.")
    print("Klasördeki 'turkiye_sismik_yogunluk_haritasi.html' dosyasını açabilirsin.")

except Exception as e:
    print(f"Hata detayı: {e}")